﻿Imports System.Data.OleDb
Module modConnection
    Public con As New OleDb.OleDbConnection
    Public cmd As New OleDb.OleDbCommand
    Public sdr As OleDbDataReader

    Public Sub connection()
        con = New OleDb.OleDbConnection
        With con
            'Provider must be Microsoft.Jet.OLEDB.4.0, find the access file, and test the connection
            .ConnectionString = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source=" & Application.StartupPath & "\Inventory.accdb"
            .Open()
        End With
    End Sub

End Module