﻿Public Class Form3
    Dim drag As Boolean
    Dim mousex As Integer
    Dim mousey As Integer

    Private Sub Button5_Click_1(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button5.Click
        'If one textbox doesn't have value, a msgbox will appear
        If Me.idbox.Text = "" Or Me.namebox.Text = "" Or Me.catbox.Text = "" Or Me.quanbox.Text = "" Then
            MsgBox("Please fill-up all fields!", MsgBoxStyle.Exclamation, "Add New Item!")
        Else
            'If all have value, proceed with inserting data.
            Try
                cmd = New OleDb.OleDbCommand
                With cmd
                    .Connection = con
                    .CommandType = CommandType.Text
                    .CommandText = "INSERT INTO tblitem (ID,pname,category,quantity) VALUES (@id,@productname,@category,@quantity)"

                    .Parameters.Add(New System.Data.OleDb.OleDbParameter("@id", System.Data.OleDb.OleDbType.VarChar, 255, Me.idbox.Text))
                    .Parameters.Add(New System.Data.OleDb.OleDbParameter("@productname", System.Data.OleDb.OleDbType.VarChar, 255, Me.namebox.Text))
                    .Parameters.Add(New System.Data.OleDb.OleDbParameter("@category", System.Data.OleDb.OleDbType.VarChar, 255, Me.catbox.Text))
                    .Parameters.Add(New System.Data.OleDb.OleDbParameter("@quantity", System.Data.OleDb.OleDbType.VarChar, 255, Me.quanbox.Text))


                    ' RUN THE COMMAND
                    cmd.Parameters("@id").Value = Me.idbox.Text
                    cmd.Parameters("@productname").Value = Me.namebox.Text
                    cmd.Parameters("@category").Value = Me.catbox.Text
                    cmd.Parameters("@quantity").Value = Me.quanbox.Text


                    cmd.ExecuteNonQuery()
                    MsgBox("Record saved.", MsgBoxStyle.Information)
                    'Will clear all textbox
                    Me.idbox.Text = ""
                    Me.namebox.Text = ""
                    Me.catbox.Text = ""
                    Me.quanbox.Text = ""
                    'Will hide and reload form2.
                    Me.Hide()
                    Form2.TblitemTableAdapter.Fill(Form2.InventoryDataSet.tblitem)
                    Form2.Show()
                    Exit Sub
                End With
            Catch ex As Exception
                MsgBox(ex.Message, MsgBoxStyle.Critical)
            End Try
        End If
    End Sub
    'This will clear all textbox
    Private Sub Button6_Click_1(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button6.Click
        Me.idbox.Text = ""
        Me.namebox.Text = ""
        Me.catbox.Text = ""
        Me.quanbox.Text = ""
    End Sub
    'This will go back to form2
    Private Sub Button7_Click_1(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button7.Click
        Me.Hide()
        Form2.Show()
    End Sub



    Private Sub Form3_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Me.FormBorderStyle = FormBorderStyle.None
        Me.Height = 510
        Me.Width = 530
        Dim p As New Drawing2D.GraphicsPath()
        p.StartFigure()
        p.AddArc(New Rectangle(0, 0, 40, 40), 180, 90)
        p.AddLine(40, 0, Me.Width - 40, 0)
        p.AddArc(New Rectangle(Me.Width - 40, 0, 40, 40), -90, 90)
        p.AddLine(Me.Width, 40, Me.Width, Me.Height - 40)
        p.AddArc(New Rectangle(Me.Width - 40, Me.Height - 40, 40, 40), 0, 90)
        p.AddLine(Me.Width - 40, Me.Height, 40, Me.Height)
        p.AddArc(New Rectangle(0, Me.Height - 40, 40, 40), 90, 90)
        p.CloseFigure()
        Me.Region = New Region(p)
        Me.Opacity = 1.0F
    End Sub

    Private Sub Label6_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Label6.Click
        Me.WindowState = FormWindowState.Minimized
    End Sub

    Private Sub Label18_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Label18.Click
        Me.Close()
    End Sub

    '-------------------Move The Form Code -----------------------------
    Private Sub Form3_MouseMove(ByVal sender As System.Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles MyBase.MouseMove
        If drag Then
            Me.Top = Windows.Forms.Cursor.Position.Y - mousey
            Me.Left = Windows.Forms.Cursor.Position.X - mousex
        End If
    End Sub

    Private Sub Form3_MouseDown(ByVal sender As System.Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles MyBase.MouseDown
        drag = True
        mousex = Windows.Forms.Cursor.Position.X - Me.Left
        mousey = Windows.Forms.Cursor.Position.Y - Me.Top
    End Sub

    Private Sub Form3_MouseUp(ByVal sender As System.Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles MyBase.MouseUp
        drag = False
    End Sub
    '-------------------Move The Form Code -----------------------------

End Class