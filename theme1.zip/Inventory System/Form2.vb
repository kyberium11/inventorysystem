﻿Public Class Form2
    Dim drag As Boolean
    Dim mousex As Integer
    Dim mousey As Integer
    Public isAdmin As Integer
    Public fName As String = ""
    Public lName As String = ""
    Public profpic As String = ""
    Public Age As String = ""
    Public Adress As String = ""
    Public PhoneNumber As String = ""
    Public Picformat As String = ""

    Private Sub TblitemBindingNavigatorSaveItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)
        Me.Validate()
        Me.TblitemBindingSource.EndEdit()
        Me.TableAdapterManager.UpdateAll(Me.InventoryDataSet)

    End Sub

    Private Sub Form2_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        'Design -----------------------------------------
        Me.FormBorderStyle = FormBorderStyle.None
        Me.Height = 778
        Me.Width = 1183
        Dim p As New Drawing2D.GraphicsPath()
        p.StartFigure()
        p.AddArc(New Rectangle(0, 0, 40, 40), 180, 90)
        p.AddLine(40, 0, Me.Width - 40, 0)
        p.AddArc(New Rectangle(Me.Width - 40, 0, 40, 40), -90, 90)
        p.AddLine(Me.Width, 40, Me.Width, Me.Height - 40)
        p.AddArc(New Rectangle(Me.Width - 40, Me.Height - 40, 40, 40), 0, 90)
        p.AddLine(Me.Width - 40, Me.Height, 40, Me.Height)
        p.AddArc(New Rectangle(0, Me.Height - 40, 40, 40), 90, 90)
        p.CloseFigure()
        Me.Region = New Region(p)
        Me.Opacity = 1.0F
        '--------------------------------------------------

        'TODO: This line of code loads data into the 'InventoryDataSet.tblitem' table. You can move, or remove it, as needed.
        Me.TblitemTableAdapter.Fill(Me.InventoryDataSet.tblitem)
        'This is for ADMIN AND CREW ACCESS
        isAdmin = sdr("PRIVELEDGE")
        fName = sdr("FNAME")
        lName = sdr("LNAME")
        profpic = sdr("Picture")
        Age = sdr("Age")
        Adress = sdr("Adress")
        PhoneNumber = sdr("PhoneNumber")
        sdr.Read()
        If isAdmin = 0 Then
            Button1.Enabled = False
            Button2.Enabled = False
            Button3.Enabled = False
            Button5.Enabled = False
            Button6.Enabled = False
            Label1.Text = "USER"
        End If
        If isAdmin = 1 Then
            Panel1.Show()
            Button1.Enabled = True
            Button2.Enabled = True
            Button3.Enabled = True
            Label1.Text = "ADMIN"
        End If

        'Disabled the Textboxes
        idbox.Enabled = False
        namebox.Enabled = False
        catbox.Enabled = False
        quanbox.Enabled = False


        'Will show database information on labels
        Label5.Text = fName + " " + lName
        Label6.Text = Age
        Label7.Text = Adress
        Label8.Text = PhoneNumber
        'Will show picture on picturebox
        Dim id As String = profpic
        Dim folder As String = Application.StartupPath & "\img\"
        Dim filename As String = System.IO.Path.Combine(folder, id & ".jpeg")
        PictureBox1.Image = Image.FromFile(filename)
    End Sub
    '-------------------Move The Form Code -----------------------------
    Private Sub Form2_MouseMove(ByVal sender As System.Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles MyBase.MouseMove
        If drag Then
            Me.Top = Windows.Forms.Cursor.Position.Y - mousey
            Me.Left = Windows.Forms.Cursor.Position.X - mousex
        End If
    End Sub

    Private Sub Form2_MouseDown(ByVal sender As System.Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles MyBase.MouseDown
        drag = True
        mousex = Windows.Forms.Cursor.Position.X - Me.Left
        mousey = Windows.Forms.Cursor.Position.Y - Me.Top
    End Sub

    Private Sub Form1_MouseUp(ByVal sender As System.Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles MyBase.MouseUp
        drag = False
    End Sub
    '-------------------Move The Form Code -----------------------------
    
    'Will logout
    Private Sub Button4_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button4.Click
        Dim msg = MsgBox("Are you sure you want to log out?", vbYesNo, "Log Out")
        If msg = MsgBoxResult.Yes Then
            Me.Close()
            Form1.Show()
            Form1.TextBox1.Clear()
            Form1.TextBox2.Clear()
        Else : Return
        End If
    End Sub
    'Will go to add form
    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        Form3.Show()
    End Sub
    'Will refresh table
    Private Sub Button2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button2.Click
        Me.TblitemTableAdapter.Fill(Me.InventoryDataSet.tblitem)
    End Sub
    'For Deleting Item
    Private Sub Button3_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button3.Click
        'If idbox is empty, will show message
        If (idbox.Text = "") Then
            MessageBox.Show("Please Click the Item you want to delete!")
        Else
            'If there's value, will show message
            Dim msg = MsgBox("Are you sure you want to delete the item?", MsgBoxStyle.YesNo, "Warning")
            If msg = MsgBoxResult.Yes Then
                'Will pass value from idbox to textbox and will delete
                TextBox1.Text = idbox.Text
                cmd = New OleDb.OleDbCommand("delete from tblitem where ID =@sno", con)
                cmd.Parameters.AddWithValue("@sno", TextBox1.Text)
                cmd.ExecuteNonQuery()
                MsgBox("Record Deleted")
                TextBox1.Clear()
                Label2.Visible = False
                TextBox1.Visible = False
                Button1.Enabled = True
                Button2.Enabled = True
                Button5.Enabled = True
                Me.TblitemTableAdapter.Fill(Me.InventoryDataSet.tblitem)
            Else : Return
            End If

        End If

    End Sub

    'ADD ITEM MENU CLICK
    Private Sub AddItemToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles AddItemToolStripMenuItem.Click
        If Label1.Text = "USER" Then
            MessageBox.Show("You do not have the right access!", "Warning!", _
          MessageBoxButtons.OK, MessageBoxIcon.Warning)
        Else
            Form3.Show()
        End If

    End Sub

    'aBOUT MENU CLICK
    Private Sub AboutToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles AboutToolStripMenuItem.Click
        About.Show()
    End Sub
    'Add User Menu Click
    Private Sub AddUserToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles AddUserToolStripMenuItem.Click
        If Label1.Text = "USER" Then
            MessageBox.Show("You do not have the right access!", "Warning!", _
          MessageBoxButtons.OK, MessageBoxIcon.Warning)
        Else
            createuserprofile.Show()
        End If
    End Sub
    'eND Menu

    'VIEWING THE DATA REALTIME BY CLICK DATAGRID CELLS
    Private Sub DataGridView_CellClick(ByVal sender As Object, ByVal e As System.Windows.Forms.DataGridViewCellEventArgs) Handles TblitemDataGridView.CellClick
        Dim i As Integer
        i = TblitemDataGridView.CurrentRow.Index
        Me.idbox.Text = TblitemDataGridView.Item(0, i).Value
        Me.namebox.Text = TblitemDataGridView.Item(1, i).Value
        Me.catbox.Text = TblitemDataGridView.Item(2, i).Value
        Me.quanbox.Text = TblitemDataGridView.Item(3, i).Value
    End Sub
    'Update button and will activate textboxes
    Private Sub Button5_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button5.Click
        namebox.Enabled = True
        catbox.Enabled = True
        quanbox.Enabled = True
        Me.Button5.Visible = False
        Me.Button6.Visible = True
    End Sub
    'Save button: Will save data to table
    Private Sub Button6_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button6.Click
        Dim msg = MsgBox("Are you sure you want to update the data?", MsgBoxStyle.YesNo, "Warning")
        If msg = MsgBoxResult.Yes Then
            cmd = New OleDb.OleDbCommand("UPDATE tblitem SET pname = @pname, category = @catbox, quantity = @quanbox WHERE ID =@idbox", con)
            cmd.Parameters.AddWithValue("@pname", Me.namebox.Text)
            cmd.Parameters.AddWithValue("@catbox", Me.catbox.Text)
            cmd.Parameters.AddWithValue("@quanbox", Me.quanbox.Text)
            cmd.Parameters.AddWithValue("@idbox", Me.idbox.Text)
            cmd.ExecuteNonQuery()
            MsgBox("Record Updated!")
            Me.TblitemTableAdapter.Fill(Me.InventoryDataSet.tblitem)
            namebox.Enabled = False
            catbox.Enabled = False
            quanbox.Enabled = False
            Me.Button5.Visible = True
            Me.Button6.Visible = False
        Else
            Dim i As Integer
            i = TblitemDataGridView.CurrentRow.Index
            Me.idbox.Text = TblitemDataGridView.Item(0, i).Value
            Me.namebox.Text = TblitemDataGridView.Item(1, i).Value
            Me.catbox.Text = TblitemDataGridView.Item(2, i).Value
            Me.quanbox.Text = TblitemDataGridView.Item(3, i).Value
        End If

    End Sub


    'Right Menu
    'X button
    Private Sub Label18_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Label18.Click
        Dim msg = MsgBox("Are you sure you want to Quit?", vbYesNo, "Warning!")
        If msg = MsgBoxResult.Yes Then
            Application.Exit()
        Else
            Return
        End If
    End Sub
    ' - Button
    Private Sub Label3_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Label3.Click
        Me.WindowState = FormWindowState.Minimized
    End Sub

    
End Class