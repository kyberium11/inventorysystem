﻿

Public Class Form1
    Dim drag As Boolean
    Dim mousex As Integer
    Dim mousey As Integer
    Dim inlogin As Integer = 0

    Private Sub Form1_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Call connection()
        TextBox2.Focus()
        'Form Design
        Me.FormBorderStyle = FormBorderStyle.None
        Me.Height = 300
        Me.Width = 400
        Dim p As New Drawing2D.GraphicsPath()
        p.StartFigure()
        p.AddArc(New Rectangle(0, 0, 40, 40), 180, 90)
        p.AddLine(40, 0, Me.Width - 40, 0)
        p.AddArc(New Rectangle(Me.Width - 40, 0, 40, 40), -90, 90)
        p.AddLine(Me.Width, 40, Me.Width, Me.Height - 40)
        p.AddArc(New Rectangle(Me.Width - 40, Me.Height - 40, 40, 40), 0, 90)
        p.AddLine(Me.Width - 40, Me.Height, 40, Me.Height)
        p.AddArc(New Rectangle(0, Me.Height - 40, 40, 40), 90, 90)
        p.CloseFigure()
        Me.Region = New Region(p)
        Me.Opacity = 0.9F


    End Sub

    Private Sub Form1_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles Me.KeyPress
        'Tab Function
        If e.KeyChar = Microsoft.VisualBasic.ChrW(Keys.Return) Then
            SendKeys.Send("{TAB}")
            e.Handled = True
        End If
        'Escape Function
        If e.KeyChar = Microsoft.VisualBasic.ChrW(Keys.Escape) Then
            Close()
        End If
    End Sub

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
      
        cmd = New OleDb.OleDbCommand( _
                   "SELECT * FROM tbluser WHERE USERNAME = '" & _
                   TextBox1.Text & "' AND [PASSWORD] = '" & TextBox2.Text & "' ", con)
        Dim user As String = ""
        Dim pass As String = ""
        sdr = cmd.ExecuteReader()
        If (sdr.Read() = True) Then
            user = sdr("USERNAME")
            pass = sdr("PASSWORD")
            MessageBox.Show("Login Successfully!")
            Me.Hide()
            Form2.Show()
        Else
            'Give 3 times to login
            inlogin = inlogin + 1
            MessageBox.Show("Invalid username or password! " & inlogin & " of 3 times tried!")
            If inlogin > 2 Then
                MsgBox("You have tried " & inlogin & " times. Application will Close", vbCritical, "Warning")
                Me.Close()
            End If
        End If
    End Sub



    Private Sub Form1_MouseMove(ByVal sender As System.Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles MyBase.MouseMove
        If drag Then
            Me.Top = Windows.Forms.Cursor.Position.Y - mousey
            Me.Left = Windows.Forms.Cursor.Position.X - mousex
        End If
    End Sub

    Private Sub Form1_MouseDown(ByVal sender As System.Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles MyBase.MouseDown
        drag = True
        mousex = Windows.Forms.Cursor.Position.X - Me.Left
        mousey = Windows.Forms.Cursor.Position.Y - Me.Top
    End Sub

    Private Sub Form1_MouseUp(ByVal sender As System.Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles MyBase.MouseUp
        drag = False
    End Sub

   
    Private Sub Label1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Label1.Click
        Dim msg = MsgBox("Are you sure you want to Quit?", vbYesNo, "Warning!")
        If msg = MsgBoxResult.Yes Then
            Application.Exit()
        Else
            Return
        End If

    End Sub

    Private Sub Label2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Label2.Click
        Me.WindowState = FormWindowState.Minimized
    End Sub

   


End Class