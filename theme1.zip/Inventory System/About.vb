﻿Public Class About
    Dim drag As Boolean
    Dim mousex As Integer
    Dim mousey As Integer

    Private Sub About_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        'Design -----------------------------------------
        Me.FormBorderStyle = FormBorderStyle.None
        Me.Height = 410
        Me.Width = 330
        Dim p As New Drawing2D.GraphicsPath()
        p.StartFigure()
        p.AddArc(New Rectangle(0, 0, 40, 40), 180, 90)
        p.AddLine(40, 0, Me.Width - 40, 0)
        p.AddArc(New Rectangle(Me.Width - 40, 0, 40, 40), -90, 90)
        p.AddLine(Me.Width, 40, Me.Width, Me.Height - 40)
        p.AddArc(New Rectangle(Me.Width - 40, Me.Height - 40, 40, 40), 0, 90)
        p.AddLine(Me.Width - 40, Me.Height, 40, Me.Height)
        p.AddArc(New Rectangle(0, Me.Height - 40, 40, 40), 90, 90)
        p.CloseFigure()
        Me.Region = New Region(p)
        '--------------------------------------------------
    End Sub

    '-------------------Move The Form Code -----------------------------
    Private Sub createuserprofile_MouseMove(ByVal sender As System.Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles MyBase.MouseMove
        If drag Then
            Me.Top = Windows.Forms.Cursor.Position.Y - mousey
            Me.Left = Windows.Forms.Cursor.Position.X - mousex
        End If
    End Sub

    Private Sub createuserprofile_MouseDown(ByVal sender As System.Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles MyBase.MouseDown
        drag = True
        mousex = Windows.Forms.Cursor.Position.X - Me.Left
        mousey = Windows.Forms.Cursor.Position.Y - Me.Top
    End Sub

    Private Sub createuserprofile_MouseUp(ByVal sender As System.Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles MyBase.MouseUp
        drag = False
    End Sub
    '-------------------Move The Form Code -----------------------------

    Private Sub Panel1_Paint(ByVal sender As System.Object, ByVal e As System.Windows.Forms.PaintEventArgs) Handles Panel1.Paint
        Dim p As New Drawing2D.GraphicsPath()
        p.StartFigure()
        p.AddArc(New Rectangle(0, 0, 40, 40), 180, 90)
        p.AddLine(40, 0, Me.Width - 40, 0)
        p.AddArc(New Rectangle(Panel1.Width - 40, 0, 40, 40), -90, 90)
        p.AddLine(Me.Width, 40, Panel1.Width, Panel1.Height - 40)
        p.AddArc(New Rectangle(Panel1.Width - 40, Panel1.Height - 40, 40, 40), 0, 90)
        p.AddLine(Me.Width - 40, Panel1.Height, 40, Panel1.Height)
        p.AddArc(New Rectangle(0, Panel1.Height - 40, 40, 40), 90, 90)
        p.CloseFigure()
        Panel1.Region = New Region(p)
    End Sub

    Private Sub Label18_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Label18.Click
        Me.Close()
    End Sub

    Private Sub Label13_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Label13.Click
        Me.WindowState = FormWindowState.Minimized
    End Sub
End Class