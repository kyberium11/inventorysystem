﻿Public Class splash

    Private Sub splash_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        
    End Sub

    Private Sub Timer1_Tick(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Timer1.Tick
        ProgressBar1.Value = ProgressBar1.Value + 1
        Label1.Text = ProgressBar1.Value
        If ProgressBar1.Value = 100 Then
            Label1.Left = Label1.Left - 25
            Label1.Text = "Finished!"
            Label2.Visible = False
            Timer1.Stop()
            ProgressBar1.Enabled = False
            Timer2.Enabled = True
        End If
    End Sub

    
    Private Sub Timer2_Tick(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Timer2.Tick
        Me.Hide()
        Form1.Show()
        Timer1.Stop()
        ProgressBar1.Enabled = False
        Timer2.Enabled = False
    End Sub
End Class