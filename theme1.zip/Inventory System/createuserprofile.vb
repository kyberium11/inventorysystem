﻿Imports System.IO
Imports System.Data.OleDb
Public Class createuserprofile
    Public filename As String = ""
    Dim drag As Boolean
    Dim mousex As Integer
    Dim mousey As Integer

    'Call connection
    Private Sub createuserprofile_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Call connection()

        'Design -----------------------------------------
        Me.FormBorderStyle = FormBorderStyle.None
        Me.Height = 594
        Me.Width = 600
        Dim p As New Drawing2D.GraphicsPath()
        p.StartFigure()
        p.AddArc(New Rectangle(0, 0, 40, 40), 180, 90)
        p.AddLine(40, 0, Me.Width - 40, 0)
        p.AddArc(New Rectangle(Me.Width - 40, 0, 40, 40), -90, 90)
        p.AddLine(Me.Width, 40, Me.Width, Me.Height - 40)
        p.AddArc(New Rectangle(Me.Width - 40, Me.Height - 40, 40, 40), 0, 90)
        p.AddLine(Me.Width - 40, Me.Height, 40, Me.Height)
        p.AddArc(New Rectangle(0, Me.Height - 40, 40, 40), 90, 90)
        p.CloseFigure()
        Me.Region = New Region(p)
        Me.Opacity = 1.0F

        '--------------------------------------------------
    End Sub

    'Browse Button to get Picture
    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        'If fields are blank, will show message
        If (fname.Text = "" Or lname.Text = "" Or Adress.Text = "" Or Age.Text = "" Or PhoneNumber.Text = "" Or Username.Text = "" Or Password.Text = "") Then
            MessageBox.Show("Please fill out the fields first!")
        Else
            'Code for Getting the picture from machine
            Dim OpenFileDialog1 As New OpenFileDialog
            OpenFileDialog1.Filter = "Picture Files (*)|*.bmp;*.gif;*.jpg"
            If OpenFileDialog1.ShowDialog = Windows.Forms.DialogResult.OK Then
                'Post pic on picturebox
                PictureBox1.Image = Image.FromFile(OpenFileDialog1.FileName)
                'Copying picture to own directory and giving it a name
                filename = fname.Text + lname.Text
                System.IO.File.Copy(OpenFileDialog1.FileName, Application.StartupPath & "\img\" & filename & ".jpeg")
            End If
        End If
    End Sub

    'Button for Creating User Profile
    Private Sub Button2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button2.Click
        'If fields are empty, will show message
        If (fname.Text = "" Or lname.Text = "" Or Adress.Text = "" Or Age.Text = "" Or PhoneNumber.Text = "" Or Username.Text = "" Or Password.Text = "") Then
            MessageBox.Show("Please fill out the fields first!")
        Else
            Try
                'getting databese con
                cmd = New OleDb.OleDbCommand
                With cmd
                    .Connection = con
                    .CommandType = CommandType.Text
                    .CommandText = "INSERT INTO tbluser ([FNAME], [LNAME], [Adress], [Age], [PhoneNumber], [USERNAME], [PASSWORD], [PRIVELEDGE], [PICTURE]) VALUES (@FNAME, @LNAME, @Adress, @Age, @PhoneNumber, @USERN, @PASS, @PRIV, @PIC)"
                    'Containing param
                    .Parameters.Add(New System.Data.OleDb.OleDbParameter("@FNAME", System.Data.OleDb.OleDbType.VarChar, 255, Me.fname.Text))
                    .Parameters.Add(New System.Data.OleDb.OleDbParameter("@LNAME", System.Data.OleDb.OleDbType.VarChar, 255, Me.lname.Text))
                    .Parameters.Add(New System.Data.OleDb.OleDbParameter("@Adress", System.Data.OleDb.OleDbType.VarChar, 255, Me.Adress.Text))
                    .Parameters.Add(New System.Data.OleDb.OleDbParameter("@Age", System.Data.OleDb.OleDbType.VarChar, 255, Me.Age.Text))
                    .Parameters.Add(New System.Data.OleDb.OleDbParameter("@PhoneNumber", System.Data.OleDb.OleDbType.VarChar, 255, Me.PhoneNumber.Text))
                    .Parameters.Add(New System.Data.OleDb.OleDbParameter("@USERN", System.Data.OleDb.OleDbType.VarChar, 255, Me.Username.Text))
                    .Parameters.Add(New System.Data.OleDb.OleDbParameter("@PASS", System.Data.OleDb.OleDbType.VarChar, 255, Me.Password.Text))
                    .Parameters.Add(New System.Data.OleDb.OleDbParameter("@PRIV", System.Data.OleDb.OleDbType.Integer, 10))
                    .Parameters.Add(New System.Data.OleDb.OleDbParameter("@PIC", System.Data.OleDb.OleDbType.VarChar, 255))
                    'Giving param values by input fields
                    cmd.Parameters("@FNAME").Value = Me.fname.Text
                    cmd.Parameters("@LNAME").Value = Me.lname.Text
                    cmd.Parameters("@Adress").Value = Me.Adress.Text
                    cmd.Parameters("@Age").Value = Me.Age.Text
                    cmd.Parameters("@PhoneNumber").Value = Me.PhoneNumber.Text
                    cmd.Parameters("@USERN").Value = Me.Username.Text
                    cmd.Parameters("@PASS").Value = Me.Password.Text
                    cmd.Parameters("@PIC").Value = filename

                    'Giving priveledge value by radiobuttons
                    If (RadioButton1.Checked = True) Then
                        cmd.Parameters("@PRIV").Value = "0"
                    ElseIf (RadioButton2.Checked = True) Then
                        cmd.Parameters("@PRIV").Value = "1"
                    End If
                    'execute command 
                    cmd.ExecuteNonQuery()
                    MsgBox("New User Profile Created!.", MsgBoxStyle.Information)
                    Me.Hide()
                    'Will prompt if want to log out
                    Dim msg = MsgBox("Do you want to log out now?", vbYesNo, "Warning!")
                    If msg = MsgBoxResult.Yes Then
                        Me.Close()
                        Form2.Close()
                        Form3.Close()
                        About.Close()
                        Form1.Show()
                        Form1.TextBox1.Clear()
                        Form1.TextBox2.Clear()
                    Else
                        Me.Hide()
                        Form2.Show()
                    End If

                End With
            Catch ex As Exception
                MsgBox(ex.Message, MsgBoxStyle.Critical)
            End Try
        End If
    End Sub

    'Clear Button
    Private Sub Button3_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button3.Click
        Me.fname.Clear()
        Me.lname.Clear()
        Me.Adress.Clear()
        Me.Age.Clear()
        Me.PhoneNumber.Clear()
        Me.Username.Clear()
        Me.Password.Clear()
        Me.Hide()
        Me.Show()
    End Sub
    'Cancel Button: Will show message if there are values on input fields.
    Private Sub Button4_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button4.Click
        If Not lname.Text = "" Or lname.Text = "" Or Adress.Text = "" Or Age.Text = "" Or PhoneNumber.Text = "" Or Username.Text = "" Or Password.Text = "" Then
            Dim msg = MsgBox("Data will be lost. Are you sure?", vbYesNo, "Warning")
            If msg = MsgBoxResult.Yes Then
                Me.fname.Clear()
                Me.lname.Clear()
                Me.Adress.Clear()
                Me.Age.Clear()
                Me.PhoneNumber.Clear()
                Me.Username.Clear()
                Me.Password.Clear()
                Me.Hide()
                Form2.Show()
            Else : Return
            End If
        End If
    End Sub
    '-------------------Move The Form Code -----------------------------
    Private Sub createuserprofile_MouseMove(ByVal sender As System.Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles MyBase.MouseMove
        If drag Then
            Me.Top = Windows.Forms.Cursor.Position.Y - mousey
            Me.Left = Windows.Forms.Cursor.Position.X - mousex
        End If
    End Sub

    Private Sub createuserprofile_MouseDown(ByVal sender As System.Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles MyBase.MouseDown
        drag = True
        mousex = Windows.Forms.Cursor.Position.X - Me.Left
        mousey = Windows.Forms.Cursor.Position.Y - Me.Top
    End Sub

    Private Sub createuserprofile_MouseUp(ByVal sender As System.Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles MyBase.MouseUp
        drag = False
    End Sub
    '-------------------Move The Form Code -----------------------------

    Private Sub Label18_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Label18.Click
        Me.Close()
    End Sub

    Private Sub Label13_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Label13.Click
        Me.WindowState = FormWindowState.Minimized
    End Sub
End Class